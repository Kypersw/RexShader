#version 120
#include "/program/gbuffers_emissive.fsh"
