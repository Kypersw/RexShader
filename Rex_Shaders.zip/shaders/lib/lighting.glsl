#ifndef LIGHTING_GLSL
#define LIGHTING_GLSL
#ifndef NO_SHADOW
uniform sampler2DShadow shadowtex0;
const bool shadowHardwareFiltering = true;
float sampleShadow(vec3 sp) {
    if (sp.x < 0.0 || sp.y < 0.0 || sp.x > 1.0 || sp.y > 1.0 || sp.z > 1.0) return 1.0;
    sp.z -= 0.0001;
#if SHADOW_FILTER == 0
    return shadow2D(shadowtex0, sp).x;
#elif SHADOW_FILTER == 1
    float t = 1.0 / float(shadowMapResolution);
    float s = 0.0;
    s += shadow2D(shadowtex0, sp + vec3(-0.75, -0.75, 0.0) * t).x;
    s += shadow2D(shadowtex0, sp + vec3( 0.75, -0.75, 0.0) * t).x;
    s += shadow2D(shadowtex0, sp + vec3(-0.75,  0.75, 0.0) * t).x;
    s += shadow2D(shadowtex0, sp + vec3( 0.75,  0.75, 0.0) * t).x;
    return s * 0.25;
#else
    float t = 1.0 / float(shadowMapResolution);
    float s = 0.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            s += shadow2D(shadowtex0, sp + vec3(float(x), float(y), 0.0) * t * 1.2).x;
        }
    }
    return s / 9.0;
#endif
}
#endif

float sunVisibility(vec2 lm, vec3 sp) {
#if defined NETHER || defined END
    return 0.0;
#elif defined NO_SHADOW
    return smoothstep(0.55, 0.95, lm.y);
#else
    return sampleShadow(sp) * smoothstep(0.05, 0.4, lm.y);
#endif
}

vec3 calcLighting(vec3 n, vec2 lm, vec3 sp, float sss) {
    vec3 torch = vec3(1.0, 0.58, 0.28) * pow(lm.x, 2.6) * 2.2 * TORCH_BRIGHTNESS;
#if defined NETHER
    return vec3(0.6, 0.42, 0.36) * 0.75 + torch + nightVision * 0.5;
#elif defined END
    return vec3(0.42, 0.36, 0.55) * 0.85 + torch + nightVision * 0.5;
#else
    vec3 L = normalize(shadowLightPosition);
    float NdotL = dot(n, L);
    float diff = mix(max(NdotL, 0.0) * smoothstep(0.0, 0.1, NdotL), 0.55, sss);
    float sh = 0.0;
    if (diff > 0.001) sh = sunVisibility(lm, sp);
    vec3 sun = lightColor() * diff * sh;
    vec3 amb = ambientColor() * (lm.y * lm.y) * (0.8 + 0.2 * dot(n, normalize(upPosition)));
    return sun + amb + torch + vec3(0.012 + nightVision * 0.5);
#endif
}
#endif
