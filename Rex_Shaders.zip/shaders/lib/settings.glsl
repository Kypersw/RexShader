#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL
const int shadowMapResolution = 1024; // [512 1024 1536 2048 3072]
const float shadowDistance = 96.0; // [48.0 64.0 80.0 96.0 128.0 160.0]
const float shadowDistanceRenderMul = 1.0;
const float sunPathRotation = -25.0; // [-40.0 -30.0 -25.0 -20.0 -10.0 0.0 10.0 20.0 30.0]
const float ambientOcclusionLevel = 1.0;
#define SHADOW_FILTER 1 // [0 1 2]
#define SHADOW_DISTORT 0.85
#define SUN_BRIGHTNESS 1.0 // [0.6 0.8 1.0 1.2 1.4]
#define AMBIENT_BRIGHTNESS 1.0 // [0.6 0.8 1.0 1.2 1.5]
#define TORCH_BRIGHTNESS 1.0 // [0.6 0.8 1.0 1.3 1.6]
#define WAVING_PLANTS
#define WAVING_STRENGTH 1.0 // [0.5 0.75 1.0 1.5 2.0]
#define WATER_WAVES
#define WAVE_SPEED 1.0 // [0.5 1.0 1.5 2.0]
#define WATER_ALPHA 0.55 // [0.3 0.4 0.55 0.7 0.85]
#define SSR
#define SSR_STEPS 12 // [8 12 16 24 32]
#define FOG_DENSITY 1.0 // [0.0 0.5 1.0 1.5 2.0 3.0]
#define BLOOM
#define BLOOM_STRENGTH 1.0 // [0.5 1.0 1.5 2.0]
//#define DOF
#define DOF_STRENGTH 1.0 // [0.5 1.0 2.0]
#define EXPOSURE 1.0 // [0.6 0.8 1.0 1.2 1.4 1.6]
#define SATURATION 1.0 // [0.8 0.9 1.0 1.1 1.2 1.3]
#define VIGNETTE 0.25 // [0.0 0.15 0.25 0.4]
#endif
