#ifndef COMMON_GLSL
#define COMMON_GLSL
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;
uniform vec3 cameraPosition;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float nightVision;
uniform float far;
uniform float near;
uniform int isEyeInWater;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;

vec3 toLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
float sunHeight() { return dot(normalize(sunPosition), normalize(upPosition)); }
float dayMix() { return smoothstep(-0.12, 0.12, sunHeight()); }
float sunsetMix() { return 1.0 - smoothstep(0.0, 0.22, abs(sunHeight())); }

vec3 lightColor() {
    float h = sunHeight();
    vec3 day = mix(vec3(1.0, 0.97, 0.92) * 2.5, vec3(1.0, 0.52, 0.24) * 1.8, sunsetMix());
    vec3 night = vec3(0.06, 0.08, 0.13) * 1.4;
    vec3 c = mix(night, day, dayMix());
    c *= smoothstep(0.0, 0.07, abs(h));
    c *= 1.0 - rainStrength * 0.85;
    return c * SUN_BRIGHTNESS;
}

vec3 ambientColor() {
    vec3 day = mix(vec3(0.45, 0.58, 0.80) * 1.35, vec3(0.55, 0.45, 0.45), sunsetMix());
    vec3 night = vec3(0.03, 0.04, 0.065);
    vec3 c = mix(night, day, dayMix());
    float g = dot(c, vec3(0.333));
    c = mix(c, vec3(g) * 0.8, rainStrength);
    return c * AMBIENT_BRIGHTNESS;
}

vec3 getSky(vec3 v) {
    vec3 up = normalize(upPosition);
    vec3 sd = normalize(sunPosition);
    float u = dot(v, up);
    float hz = pow(1.0 - clamp(u, 0.0, 1.0), 4.0);
    float sdot = max(dot(v, sd), 0.0);
    vec3 dayC = mix(vec3(0.12, 0.30, 0.85) * 1.1, vec3(0.62, 0.78, 1.0) * 1.15, hz);
    vec3 setC = mix(vec3(0.18, 0.22, 0.45), vec3(1.15, 0.55, 0.25), hz * (0.45 + 0.55 * sdot));
    vec3 nightC = mix(vec3(0.006, 0.009, 0.022), vec3(0.025, 0.035, 0.06), hz);
    vec3 c = mix(dayC, setC, sunsetMix());
    c = mix(nightC, c, dayMix());
    c += vec3(1.0, 0.8, 0.55) * pow(sdot, 6.0) * 0.25 * dayMix();
    if (u < 0.0) c *= mix(1.0, 0.35, clamp(-u * 3.0, 0.0, 1.0));
    float g = dot(c, vec3(0.3, 0.5, 0.2));
    c = mix(c, vec3(g) * 0.55, rainStrength);
    return c;
}
#endif
