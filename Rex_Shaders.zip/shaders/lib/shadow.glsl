#ifndef SHADOW_GLSL
#define SHADOW_GLSL
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
vec2 distortShadow(vec2 p) { return p / (length(p) * SHADOW_DISTORT + (1.0 - SHADOW_DISTORT)); }
vec3 getShadowPos(vec3 playerPos, vec3 worldNormal, float NdotL) {
    float df = clamp(length(playerPos.xz) / shadowDistance, 0.0, 1.0) * SHADOW_DISTORT + (1.0 - SHADOW_DISTORT);
    float texel = 2.0 * shadowDistance / float(shadowMapResolution) * df;
    float slope = 1.0 - clamp(NdotL, 0.0, 1.0);
    vec3 p = playerPos + worldNormal * texel * (1.5 + 3.0 * slope);
    vec4 sc = shadowProjection * (shadowModelView * vec4(p, 1.0));
    sc.xy = distortShadow(sc.xy);
    return sc.xyz * 0.5 + 0.5;
}
#endif
