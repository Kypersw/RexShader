#ifndef WAVE_GLSL
#define WAVE_GLSL
vec3 waveOffset(vec3 wp, float id, bool top) {
    float t = frameTimeCounter;
    float str = WAVING_STRENGTH * (1.0 + rainStrength);
    vec3 o = vec3(0.0);
    if (id > 10000.5 && id < 10001.5) {
        o.x = sin(t * 1.7 + wp.x * 1.3 + wp.z * 0.7) * 0.04;
        o.z = cos(t * 1.3 + wp.z * 1.1 + wp.y * 0.9) * 0.04;
        o.y = sin(t * 2.1 + wp.x + wp.z) * 0.02;
    } else if ((id > 10002.5 && id < 10003.5 && top) || (id > 10003.5 && id < 10004.5)) {
        float a = (id > 10003.5 && top) ? 1.6 : 1.0;
        o.x = (sin(t * 2.0 + wp.x * 0.9 + wp.z * 0.5) * 0.08 + sin(t * 3.7 + wp.z) * 0.03) * a;
        o.z = cos(t * 1.7 + wp.z * 0.8 + wp.x * 0.3) * 0.06 * a;
    }
    return o * str;
}
#endif
