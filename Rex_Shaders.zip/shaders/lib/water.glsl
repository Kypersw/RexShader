#ifndef WATER_GLSL
#define WATER_GLSL
float waterH(vec2 p) {
    float t = frameTimeCounter * WAVE_SPEED;
    return sin(p.x * 0.7 + t * 1.1) * 0.05
         + sin(p.y * 0.9 - t * 0.9) * 0.045
         + sin((p.x + p.y) * 1.9 + t * 1.7) * 0.025
         + sin((p.x * 0.6 - p.y) * 3.3 - t * 2.3) * 0.012
         + sin((p.y * 0.8 - p.x) * 5.1 + t * 3.1) * 0.006;
}
vec3 waterNormal(vec2 p) {
    float e = 0.04;
    float dx = (waterH(p + vec2(e, 0.0)) - waterH(p - vec2(e, 0.0))) / (2.0 * e);
    float dz = (waterH(p + vec2(0.0, e)) - waterH(p - vec2(0.0, e))) / (2.0 * e);
    return normalize(vec3(-dx, 1.0, -dz));
}
#endif
