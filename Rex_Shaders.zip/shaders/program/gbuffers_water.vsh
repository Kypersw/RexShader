#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/shadow.glsl"
attribute vec4 mc_Entity;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 shadowPos;
varying vec3 viewPos;
varying vec3 worldPos;
varying vec3 worldNormal;
varying float blockId;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp(lmcoord * 33.05 / 32.0 - 1.05 / 32.0, 0.0, 1.0);
    glcolor = gl_Color;
    blockId = mc_Entity.x;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    viewPos = vp.xyz;
    vec3 playerPos = (gbufferModelViewInverse * vp).xyz;
    worldPos = playerPos + cameraPosition;
    normal = normalize(gl_NormalMatrix * gl_Normal);
    worldNormal = mat3(gbufferModelViewInverse) * normal;
    shadowPos = vec3(0.0);
#ifndef NO_SHADOW
    shadowPos = getShadowPos(playerPos, worldNormal, dot(normal, normalize(shadowLightPosition)));
#endif
    gl_Position = gl_ProjectionMatrix * vp;
}
