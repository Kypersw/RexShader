#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
/* DRAWBUFFERS:0 */
#ifdef END
    gl_FragData[0] = vec4(toLinear(c.rgb), c.a);
#else
    gl_FragData[0] = vec4(toLinear(c.rgb) * 2.5 * (1.0 - rainStrength * 0.8), c.a);
#endif
}
