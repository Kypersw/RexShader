#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    if (c.a < 0.004) discard;
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(toLinear(c.rgb) * 1.5, c.a);
}
