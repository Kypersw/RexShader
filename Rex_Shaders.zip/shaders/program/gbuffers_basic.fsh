#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(toLinear(glcolor.rgb), glcolor.a);
}
