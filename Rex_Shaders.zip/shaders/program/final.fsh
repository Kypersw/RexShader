#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D colortex0;
varying vec2 texcoord;
const bool colortex0MipmapEnabled = true;
#ifdef DOF
uniform sampler2D depthtex0;
uniform float centerDepthSmooth;
const float centerDepthHalflife = 1.5;
float linDepth(float d) { return 2.0 * near * far / (far + near - (d * 2.0 - 1.0) * (far - near)); }
#endif
vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
#ifdef DOF
    float d = texture2D(depthtex0, texcoord).r;
    if (d > 0.56) {
        float ld = linDepth(d);
        float lf = linDepth(centerDepthSmooth);
        float coc = clamp(abs(ld - lf) / max(lf, 1.0) * DOF_STRENGTH, 0.0, 1.0);
        if (coc > 0.02) col = mix(col, texture2D(colortex0, texcoord, coc * 4.0).rgb, smoothstep(0.0, 0.5, coc));
    }
#endif
#ifdef BLOOM
    vec3 bl = texture2D(colortex0, texcoord, 3.0).rgb * 0.4
            + texture2D(colortex0, texcoord, 5.0).rgb * 0.35
            + texture2D(colortex0, texcoord, 7.0).rgb * 0.25;
    col = mix(col, bl, 0.08 * BLOOM_STRENGTH) + max(bl - 1.0, 0.0) * 0.15 * BLOOM_STRENGTH;
#endif
    col *= EXPOSURE;
    col = aces(col);
    col = pow(col, vec3(1.0 / 2.2));
    float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = clamp(mix(vec3(l), col, SATURATION), 0.0, 1.0);
    vec2 c = texcoord - 0.5;
    col *= 1.0 - dot(c, c) * VIGNETTE * 1.6;
    gl_FragColor = vec4(col, 1.0);
}
