#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
varying vec2 texcoord;
/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
*/
vec3 toView(vec2 uv, float d) {
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, d) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
vec3 toScreen(vec3 vp) {
    vec4 c = gbufferProjection * vec4(vp, 1.0);
    return c.xyz / c.w * 0.5 + 0.5;
}
#ifdef SSR
vec4 traceSSR(vec3 vp, vec3 n) {
    vec3 r = normalize(reflect(normalize(vp), n));
    if (r.z > 0.3) return vec4(0.0);
    vec3 stp = r * (0.6 + length(vp) * 0.02);
    vec3 pos = vp + n * 0.1;
    for (int i = 0; i < SSR_STEPS; i++) {
        pos += stp;
        if (pos.z > -near) break;
        vec3 sc = toScreen(pos);
        if (sc.x < 0.0 || sc.y < 0.0 || sc.x > 1.0 || sc.y > 1.0) break;
        float sd = texture2D(depthtex1, sc.xy).r;
        float diff = toView(sc.xy, sd).z - pos.z;
        if (sd < 1.0 && diff > 0.0 && diff < length(stp) * 0.8) {
            vec3 st = stp;
            for (int j = 0; j < 4; j++) {
                st *= 0.5;
                vec3 s2 = toScreen(pos);
                float dd = toView(s2.xy, texture2D(depthtex1, s2.xy).r).z - pos.z;
                pos += (dd > 0.0) ? -st : st;
            }
            vec3 s3 = toScreen(pos);
            vec2 e = smoothstep(0.0, 0.08, s3.xy) * (1.0 - smoothstep(0.92, 1.0, s3.xy));
            float sd3 = texture2D(depthtex1, s3.xy).r;
            if (abs(toView(s3.xy, sd3).z - pos.z) > 0.6) return vec4(0.0);
            return vec4(texture2D(colortex0, s3.xy).rgb, e.x * e.y * (1.0 - float(i) / float(SSR_STEPS)));
        }
        stp *= 1.35;
    }
    return vec4(0.0);
}
#endif
void main() {
    vec3 col = texture2D(colortex0, texcoord).rgb;
    float d = texture2D(depthtex0, texcoord).r;
    vec3 vp = toView(texcoord, d);
#ifdef SSR
    vec4 data = texture2D(colortex1, texcoord);
    if (d < 1.0 && dot(data.rgb, data.rgb) > 0.01 && isEyeInWater == 0) {
        vec3 n = normalize(data.rgb * 2.0 - 1.0);
        float fres = 0.02 + 0.98 * pow(1.0 - clamp(dot(-normalize(vp), n), 0.0, 1.0), 5.0);
        vec4 hit = traceSSR(vp, n);
        col = mix(col, hit.rgb, hit.a * fres * 0.75);
    }
#endif
    float dist = length(vp);
    if (d < 1.0) {
#if defined NETHER
        col = mix(col, toLinear(fogColor) * 0.6, clamp(pow(dist / far, 1.5), 0.0, 1.0));
#elif defined END
        col = mix(col, vec3(0.03, 0.02, 0.05), smoothstep(far * 0.6, far, dist));
#else
        if (isEyeInWater == 0) {
            vec3 dir = normalize(vp);
            float f = 1.0 - exp(-dist * 0.0018 * FOG_DENSITY * (1.0 + rainStrength * 4.0));
            float border = smoothstep(far * 0.7, far, dist) * (1.0 - smoothstep(0.05, 0.25, dot(dir, normalize(upPosition))));
            col = mix(col, getSky(dir), max(f, border));
        }
#endif
    }
    if (isEyeInWater == 1) {
        float wd = d < 1.0 ? dist : far;
        float f = 1.0 - exp(-wd * 0.07);
        vec3 wf = vec3(0.02, 0.11, 0.16) * (ambientColor() * 1.5 + lightColor() * 0.3 + 0.05);
        col = mix(col * vec3(0.6, 0.85, 1.0), wf, f);
    } else if (isEyeInWater == 2) {
        col = mix(col, vec3(1.0, 0.35, 0.05) * 1.5, 1.0 - exp(-dist * 0.6));
    } else if (isEyeInWater == 3) {
        col = mix(col, vec3(0.8, 0.85, 0.9), 1.0 - exp(-dist * 0.5));
    }
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(col, 1.0);
}
