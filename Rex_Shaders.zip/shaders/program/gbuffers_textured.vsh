#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/shadow.glsl"
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 shadowPos;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = clamp(lmcoord * 33.05 / 32.0 - 1.05 / 32.0, 0.0, 1.0);
    glcolor = gl_Color;
    vec3 nn = gl_Normal;
    if (dot(nn, nn) < 0.01) nn = vec3(0.0, 1.0, 0.0);
    normal = normalize(gl_NormalMatrix * nn);
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    shadowPos = vec3(0.0);
#ifndef NO_SHADOW
    vec3 playerPos = (gbufferModelViewInverse * vp).xyz;
    shadowPos = getShadowPos(playerPos, mat3(gbufferModelViewInverse) * normal, dot(normal, normalize(shadowLightPosition)));
#endif
    gl_Position = gl_ProjectionMatrix * vp;
}
