uniform sampler2D tex;
varying vec2 texcoord;
void main() {
#ifdef NO_SHADOW
    discard;
#else
    vec4 c = texture2D(tex, texcoord);
    if (c.a < 0.1) discard;
    gl_FragData[0] = c;
#endif
}
