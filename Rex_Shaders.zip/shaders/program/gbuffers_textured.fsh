#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
#ifdef ENTITY
uniform vec4 entityColor;
#endif
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 shadowPos;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;
#if defined ENTITY || defined HAND
    if (albedo.a < 0.1) discard;
#else
    if (albedo.a < 0.01) discard;
#endif
#ifdef ENTITY
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
    float sss = 0.15;
#elif defined HAND
    float sss = 0.25;
#else
    float sss = 0.6;
#endif
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(toLinear(albedo.rgb) * calcLighting(normalize(normal), lmcoord, shadowPos, sss), albedo.a);
}
