#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

void main() {
    vec4 c = texture2D(texture, texcoord) * glcolor;
    if (c.a < 0.01) discard;
    vec3 col = toLinear(c.rgb) * (lightColor() * 0.35 + ambientColor() * 1.3 + 0.02);
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(col, c.a * 0.85);
}
