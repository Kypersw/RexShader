#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 shadowPos;
varying vec3 viewPos;
varying vec3 worldPos;
varying vec3 worldNormal;
varying float blockId;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;
    vec3 n = normalize(normal);
    vec3 vdir = normalize(viewPos);
    float id = floor(blockId + 0.5);
/* DRAWBUFFERS:01 */
    if (id == 10002.0) {
#ifdef WATER_WAVES
        if (worldNormal.y > 0.5) n = normalize(mat3(gbufferModelView) * waterNormal(worldPos.xz));
#endif
        vec3 wcol = toLinear(albedo.rgb) * 0.45;
        vec3 lit = wcol * calcLighting(n, lmcoord, shadowPos, 0.0);
        float fres = 0.02 + 0.98 * pow(1.0 - clamp(dot(-vdir, n), 0.0, 1.0), 5.0);
        vec3 r = reflect(vdir, n);
#if defined NETHER || defined END
        vec3 refl = toLinear(fogColor) * 0.5;
        vec3 spec = vec3(0.0);
#else
        vec3 refl = getSky(r) * smoothstep(0.3, 0.9, lmcoord.y);
        float sp = pow(max(dot(r, normalize(shadowLightPosition)), 0.0), 300.0);
        vec3 spec = lightColor() * sp * sunVisibility(lmcoord, shadowPos) * 4.0;
#endif
        if (isEyeInWater == 1) fres *= 0.3;
        vec3 col = mix(lit, refl, fres) + spec;
        float a = mix(WATER_ALPHA, 1.0, fres);
        gl_FragData[0] = vec4(col, a);
        gl_FragData[1] = vec4(n * 0.5 + 0.5, 1.0);
    } else {
        if (albedo.a < 0.004) discard;
        vec3 col = toLinear(albedo.rgb) * calcLighting(n, lmcoord, shadowPos, 0.0);
        gl_FragData[0] = vec4(col, albedo.a);
        gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);
    }
}
