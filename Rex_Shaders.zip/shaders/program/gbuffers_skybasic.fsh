#include "/lib/settings.glsl"
#include "/lib/common.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 viewPos;

#ifdef MC_RENDER_STAGE_STARS
uniform int renderStage;
#endif
void main() {
/* DRAWBUFFERS:0 */
#ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) {
        gl_FragData[0] = vec4(toLinear(glcolor.rgb) * 1.5, glcolor.a);
        return;
    }
#endif
    gl_FragData[0] = vec4(getSky(normalize(viewPos)), 1.0);
}
