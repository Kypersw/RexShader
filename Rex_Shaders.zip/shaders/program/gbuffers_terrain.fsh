#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lighting.glsl"
uniform sampler2D texture;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 shadowPos;
varying float blockId;
void main() {
    vec4 albedo = texture2D(texture, texcoord) * glcolor;
    if (albedo.a < 0.1) discard;
    vec3 col = toLinear(albedo.rgb);
    float id = floor(blockId + 0.5);
    float sss = (id == 10001.0 || id == 10003.0 || id == 10004.0) ? 1.0 : 0.0;
    vec3 light = calcLighting(normalize(normal), lmcoord, shadowPos, sss);
    if (id == 10005.0) light = light * 0.3 + vec3(2.4);
/* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(col * light, albedo.a);
}
