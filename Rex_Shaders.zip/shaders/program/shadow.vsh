#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/shadow.glsl"
#include "/lib/wave.glsl"
attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
uniform mat4 shadowModelViewInverse;
varying vec2 texcoord;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
#ifdef NO_SHADOW
    gl_Position = vec4(10.0, 10.0, 10.0, 1.0);
    return;
#else
    if (mc_Entity.x > 10001.5 && mc_Entity.x < 10002.5) {
        gl_Position = vec4(10.0, 10.0, 10.0, 1.0);
        return;
    }
    vec3 playerPos = (shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
#ifdef WAVING_PLANTS
    playerPos += waveOffset(playerPos + cameraPosition, mc_Entity.x, gl_MultiTexCoord0.t < mc_midTexCoord.t);
#endif
    vec4 cp = gl_ProjectionMatrix * (shadowModelView * vec4(playerPos, 1.0));
    cp.xy = distortShadow(cp.xy);
    gl_Position = cp;
#endif
}
