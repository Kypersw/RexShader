#version 120
#define ENTITY
#include "/program/gbuffers_textured.fsh"
