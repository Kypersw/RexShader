#version 120
#define END
#define NO_SHADOW
#define ENTITY
#include "/program/gbuffers_textured.vsh"
