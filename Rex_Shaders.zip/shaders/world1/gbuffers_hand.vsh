#version 120
#define END
#define NO_SHADOW
#define HAND
#include "/program/gbuffers_textured.vsh"
