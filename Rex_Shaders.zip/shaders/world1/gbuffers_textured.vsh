#version 120
#define END
#define NO_SHADOW
#include "/program/gbuffers_textured.vsh"
