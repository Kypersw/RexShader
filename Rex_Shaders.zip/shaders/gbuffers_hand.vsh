#version 120
#define HAND
#define NO_SHADOW
#include "/program/gbuffers_textured.vsh"
