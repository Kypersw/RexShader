#version 120
#define NETHER
#define NO_SHADOW
#include "/program/gbuffers_clouds.fsh"
