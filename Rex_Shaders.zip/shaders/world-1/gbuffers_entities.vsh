#version 120
#define NETHER
#define NO_SHADOW
#define ENTITY
#include "/program/gbuffers_textured.vsh"
