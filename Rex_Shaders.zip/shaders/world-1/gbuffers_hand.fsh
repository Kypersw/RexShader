#version 120
#define NETHER
#define NO_SHADOW
#define HAND
#include "/program/gbuffers_textured.fsh"
